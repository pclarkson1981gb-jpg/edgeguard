// EdgeGuard core middleware logic.
// Designed for Next.js Edge Runtime.

import { NextRequest, NextResponse } from 'next/server';
import { BAD_BOTS, DEFAULT_WHITELIST } from './bot-list';

export interface EdgeGuardConfig {
  apiKey?: string;
  blockAI?: boolean;
  whitelist?: string[];
  verbose?: boolean;
}

export interface EdgeGuardResult {
  blocked: boolean;
  response?: NextResponse;
}

export function protect(
  req: NextRequest,
  config: EdgeGuardConfig = {}
): EdgeGuardResult {

  const userAgent = (req.headers.get('user-agent') || '').toLowerCase();
  const path = req.nextUrl.pathname;

  // Safety first: never interfere with critical or static paths
  const whitelist = [...DEFAULT_WHITELIST, ...(config.whitelist || [])];
  if (whitelist.some(p => path.startsWith(p))) {
    return { blocked: false };
  }

  // Open-core classification
  const matchesStaticList = BAD_BOTS.some(bot =>
    userAgent.includes(bot.toLowerCase())
  );

  // Placeholder for paid intelligence (fail-open by design)
  // In paid tiers, this would call a remote edge-safe endpoint.
  let matchesPaidIntelligence = false;

  if (config.apiKey) {
    // intentionally empty
    // future: remote classification with strict timeout and fail-open behavior
  }

  const shouldBlock =
    (matchesStaticList || matchesPaidIntelligence) &&
    config.blockAI !== false;

  if (shouldBlock) {
    if (config.verbose) {
      console.warn(
        `[EdgeGuard] Dropped automated request: ${userAgent} → ${path}`
      );
    }

    return {
      blocked: true,
      response: new NextResponse(
        JSON.stringify({
          error: 'Automated traffic dropped by EdgeGuard'
        }),
        {
          status: 403,
          headers: { 'Content-Type': 'application/json' }
        }
      )
    };
  }

  return { blocked: false };
}
