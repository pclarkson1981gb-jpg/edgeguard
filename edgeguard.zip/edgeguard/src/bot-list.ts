// Open-core bot signatures.
// These are high-volume automated agents known to trigger serverless costs.

export const BAD_BOTS = [
  'GPTBot',
  'ChatGPT-User',
  'FacebookBot',
  'Meta-ExternalAgent',
  'ClaudeBot',
  'Bytespider',
  'Amazonbot',
  'PerplexityBot',
  'CCBot',
  'anthropic-ai',
  'cohere-ai',
  'Omgilibot',
  'FacebookExternalHit'
];

// Paths that should never be blocked, regardless of configuration.
// This acts as a safety net even if matcher rules are misconfigured.

export const DEFAULT_WHITELIST = [
  '/api/auth',
  '/api/webhooks',
  '/_next/static',
  '/_next/image',
  '/favicon.ico'
];
