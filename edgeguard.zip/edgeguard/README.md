# EdgeGuard

Stop high-cost automated traffic before it hits your serverless functions.

EdgeGuard is a lightweight Next.js Edge Middleware that classifies and drops aggressive automated requests at the edge, helping reduce serverless execution costs on platforms like Vercel.

## Why this exists

Modern AI crawlers and automation agents can hit production sites at massive scale. Even when robots.txt is respected, these requests still trigger middleware, routing, and serverless execution.

On usage-based platforms, that means you pay for traffic you never wanted.

EdgeGuard runs before your application logic, allowing you to drop known high-cost automated traffic in ~0ms.

## Designed for the Edge

- Runs entirely in Next.js Edge Middleware
- No Node APIs
- No async latency
- Fail-open by design

If EdgeGuard fails, your site continues to work normally.

## Installation

```bash
npm install @edgeguard/protect
```

## Basic usage

`middleware.ts`

```typescript
import { protect } from '@edgeguard/protect';
import { NextRequest, NextResponse } from 'next/server';

export function middleware(request: NextRequest) {
  const guard = protect(request, {
    verbose: true
  });

  if (guard.blocked) {
    return guard.response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
```

## Configuration

### `apiKey`
Optional. Enables future real-time classification. Required for paid tiers.

### `blockAI`
Default `true`. Set to `false` to allow known automated agents.

### `whitelist`
Additional paths that should never be blocked.

### `verbose`
Logs dropped requests to the Vercel Edge console.

## Open core vs paid intelligence

The open-source version includes a static list of known high-volume automated agents.

Paid tiers add:
- Real-time classification updates
- Faster response to user-agent changes
- Optional analytics on dropped requests

All paid features are fail-open and never block traffic if unavailable.

## Pricing

### Indie plan
$9 per month
Designed for solo developers and small teams running on Vercel.

## License

MIT
